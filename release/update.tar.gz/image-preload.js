(() => {
  const node = document.querySelector('#image-preload-plan');
  if (!node) return;
  let plan;
  try { plan = JSON.parse(node.textContent); } catch { return; }
  const root = document.documentElement;
  const saveData = !!navigator.connection?.saveData;
  const tasks = new Map();
  const queue = [];
  const limit = saveData ? 2 : 4;
  let active = 0;
  let sequence = 0;
  const localURL = value => {
    try { const url = new URL(value, location.href); return url.origin === location.origin && /\.(?:jpg|jpeg|png|webp)$/i.test(url.pathname) ? url.href : null; } catch { return null; }
  };
  function pump() {
    queue.sort((a,b) => b.priority-a.priority || a.sequence-b.sequence);
    while (active < limit && queue.length) {
      const task = queue.shift();
      active++;
      task.state = 'loading';
      const image = new Image();
      image.decoding = 'async';
      image.fetchPriority = task.priority >= 3 ? 'auto' : 'low';
      let finished = false;
      const finish = ok => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        image.onload = image.onerror = null;
        task.state = ok ? 'ready' : 'failed';
        active--;
        task.resolve(ok);
        pump();
      };
      const timer = setTimeout(() => { image.onload = image.onerror = null; image.src = ''; finish(false); },15000);
      image.onload = () => finish(true);
      image.onerror = () => finish(false);
      image.src = task.url;
    }
  }
  function warm(value,priority=0) {
    const url = localURL(value);
    if (!url) return Promise.resolve(false);
    let task = tasks.get(url);
    if (task) {
      task.priority = Math.max(task.priority,priority);
      queue.sort((a,b) => b.priority-a.priority || a.sequence-b.sequence);
      return task.promise;
    }
    task = {url,priority,sequence:sequence++,state:'queued'};
    task.promise = new Promise(resolve => task.resolve=resolve);
    tasks.set(url,task);queue.push(task);pump();
    return task.promise;
  }
  function course(item) {
    const pages = item?.pages || [];
    pages.forEach((page,index) => warm(page.src,index < 8 ? 5 : 2));
    if (item?.poster) warm(typeof item.poster === 'string' ? item.poster : item.poster.src,4);
  }
  window.resumeImages = {warm,course};
  const selectedHero = matchMedia('(max-width:700px)').matches ? '/assets/previews/hero-mobile.webp' : '/assets/previews/hero-desktop.webp';
  const current = [...document.querySelectorAll('img')];
  current.forEach(image => {
    image.loading = 'eager';
    const picture = image.parentElement?.tagName === 'PICTURE' ? image.parentElement : null;
    const source = picture && [...picture.querySelectorAll('source')].find(source => !source.media || matchMedia(source.media).matches);
    const src = image.currentSrc || source?.srcset?.split(',')[0]?.trim().split(/\s+/)[0] || image.src;
    if (src) image.dataset.warmSrc = src;
  });
  const ordinary = (plan.images || []).filter(src => !/\/portrait-\d+\.jpg|\/hero-(?:mobile|desktop)\.webp/.test(src));
  const firstSheets = (plan.courses || []).flatMap(item => item.pages.slice(0,3).map(page=>page.src));
  const critical = [...new Set(current.map(image=>image.dataset.warmSrc).filter(Boolean).concat(saveData ? [] : [selectedHero,...ordinary,...firstSheets]))];
  const entering = root.classList.contains('is-entering');
  const started = performance.now();
  let settled = 0;
  let released = false;
  let backgroundStarted = false;
  function enter() {
    if (released) return;
    released = true;
    const delay = entering ? Math.max(0,320-(performance.now()-started)) : 0;
    setTimeout(()=>root.classList.remove('is-entering'),delay);
  }
  const deadline = setTimeout(enter,8000);
  const ready = Promise.all(critical.map(src => warm(src,3).then(ok => {
    settled++;
    document.querySelector('.entrance-track')?.style.setProperty('--entrance-progress',String(settled/Math.max(critical.length,1)));
    return ok;
  })));
  function background() {
    if (saveData || backgroundStarted) return;
    backgroundStarted = true;
    (plan.images || []).forEach(src=>warm(src,0));
    (plan.courses || []).forEach(item=>item.pages.forEach(page=>warm(page.src,0)));
    for (const href of plan.routes || []) {
      if (new URL(href,location.href).pathname === location.pathname) continue;
      const link = document.createElement('link');link.rel='prefetch';link.as='document';link.href=href;document.head.append(link);
    }
  }
  // The queue keeps loading when the safety deadline expires, rather than leaving gaps later.
  ready.then(()=>{clearTimeout(deadline);enter();background();});
  setTimeout(background,8000);
  document.addEventListener('focusin',()=>{root.classList.remove('is-entering');},{once:true});
  const prepareTarget = event => {
    const button = event.target.closest?.('[data-recording],[data-media]');
    if (button) {
      try { if(button.dataset.recording) course(JSON.parse(button.dataset.recording)); else {const item=JSON.parse(button.dataset.media);if(item.type==='image')warm(item.src,5);} } catch {}
    }
  };
  document.addEventListener('pointerover',prepareTarget,{passive:true});
  document.addEventListener('focusin',prepareTarget);
  document.addEventListener('touchstart',prepareTarget,{passive:true});
})();
